# Kryptinfo
**Easily check system information**

このコマンドで１~5版を選べばdmesg、lsb_release、lspci、uname -a、fastfetchが実行できます

名前がKryptinfoなのは将来公開する(予定の)>Krypton_という自作ディストロに搭載したいからです

まだ未完成です

初心者が作ったのでで無駄やバグが多いかもしれません。
